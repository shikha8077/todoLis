import react from 'react';
import Todo from './components/Todo';

const App =() =>{
return(
  <>
  <Todo/>
  </>
)
  
}

export default App;